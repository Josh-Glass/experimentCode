export default class EventHandler {
    constructor() {
        
    }
}