'''
Experiment
'''

## Python Standard Library
import sys
import os
import datetime
import time

## external dependencies
from psychopy import visual

## Internal Dependencies
import pyxpr.utils
from pyxpr.events import initializer, instructions, classification

settings = {
    'experiment_id': 'exp',

	'save_data': True,
    'data_folder': './subject_data',
	'show_initial_dialogue': True,

	'subject_data_folder': './subject_data',
    'window_color': [1,1,1],
    'debug_mode': False,
}


# # # # # # # # # # # # # # # # # 
# 
#  SETUP
# 
# # # # # # # # # # # # # # # # # 

settings['experiment_time'] = '-'.join([str(d) for d in datetime.datetime.now().timetuple()][:6])

# Show initial dialogue window if True
if settings['show_initial_dialogue'] == True:
	initial_info = initializer.run(conditions=list([1,2]))
else:
	initial_info = ['debug', 1]

# Define Subject Dictionary (this is where we'll store all the information about the subject)
subject = {
	'id': str(initial_info[0]),
	'condition': int(initial_info[1]),
	'datafile_path': os.path.join(settings['data_folder'], str(initial_info[0]) + '_' + settings['experiment_time'] + '.csv')
}

if settings['save_data'] == True:
	with open(subject['datafile_path'], 'w'):
		pass

if subject['id'] == 'debug':
	settings['debug_mode'] = True

## build experiment window (little bit faster to pass the window as an argument to each event rather than making a new one on the fly each time an event changes)
if settings.get('window_size', 'full') == 'full':
	win = visual.Window(fullscr = True, units = 'pix', color = settings.get('window_color', [1,1,1]))
else:
	win = visual.Window(settings['window_size'], units = 'pix', color = settings.get('window_color', [1,1,1]))






# # # # # # # # # # # # # # # # # 
# 
#  Run Experiment
# 
# # # # # # # # # # # # # # # # # 




# - - - Phase 1 - Training (with feedback) - - - 

#condition 1
if int(initial_info[1]) == 1:
    # instructions function
    instructions.run(
        text_file = 'materials/instructions/C1_Train1.txt',	
        
        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
    )


    stimuli_train = [
        'materials/images/0.png',
        'materials/images/1.png',
        'materials/images/2.png',
        'materials/images/3.png',
        'materials/images/4.png',
        'materials/images/5.png',
        'materials/images/6.png',
        'materials/images/7.png',
        'materials/images/8.png',
        'materials/images/9.png',
        'materials/images/10.png',
        'materials/images/11.png',
    ]

    labels_train = [
        'Alpha', 
        'Alpha', 
        'Alpha',
        'Alpha',
        'Alpha',
        'Alpha',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        ]

    # classification phase function
    classification.run(
        stimuli_train,
        labels = labels_train,

        phase_id = 'training_phase_1',
        supervised = True, # <-- this means there will be feedback
        randomize_presentation = True,
        num_blocks = 1,

        window = win,
        experiment_id = settings['experiment_id'],
        subject_info = subject,
        save_data = True,
        debug_mode = False,
        
        feedback_txt_position = [0, 250],
        click_instructions_position = [0, 200],
        continue_txt_position = [0, 200]
    )




    # - - - Phase 2 - Test (no feedback) - - -

    # instructions function
    instructions.run(
        text_file = './materials/instructions/C1_Test.txt',

        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
        
        
    
    )


    stimuli_test = [
        'materials/images/0.png',
        'materials/images/1.png',
        'materials/images/2.png',
        'materials/images/3.png',
        'materials/images/4.png',
        'materials/images/5.png',
        'materials/images/6.png',
        'materials/images/7.png',
        'materials/images/8.png',
        'materials/images/9.png',
        'materials/images/10.png',
        'materials/images/11.png',
        'materials/images/12.png',
        'materials/images/13.png',
        'materials/images/14.png',
        'materials/images/15.png',
        'materials/images/15.png',
    ]

    labels_test = [
        'Alpha', 
        'Alpha', 
        'Alpha',
        'Alpha',
        'Alpha',
        'Alpha',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'test',
        'test',
        'test',
        'test',
        'test']

    # classification phase function
    classification.run(
        stimuli_test,
        labels = labels_test,
        response_btn_labels = ['Alpha','Beta'],

        phase_id = 'test_phase',
        supervised = False, # <-- no feedback
        randomize_presentation = True,
        num_blocks = 1,

        window = win,
        experiment_id = settings['experiment_id'],
        subject_info = subject,
        save_data = True,
        debug_mode = settings['debug_mode'],
        
        
        click_instructions_position = [0, 200],
        continue_txt_position = [0, 200]
    )
    
    #   Phase 3<--training_phase_2
        # instructions function
    instructions.run(
        text_file = 'materials/instructions/C1_Train2.txt',	
        
        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
    )


    stimuli_train = [
        'materials/images/0.png',
        'materials/images/1.png',
        'materials/images/2.png',
        'materials/images/3.png',
        'materials/images/4.png',
        'materials/images/5.png',
        'materials/images/6.png',
        'materials/images/7.png',
        'materials/images/8.png',
        'materials/images/9.png',
        'materials/images/10.png',
        'materials/images/11.png',
        'materials/images/17.png',
        'materials/images/18.png',
        'materials/images/19.png',
        'materials/images/20.png',
        'materials/images/21.png',
        'materials/images/22.png',
        'materials/images/23.png',
        'materials/images/24.png',
        'materials/images/25.png',
        'materials/images/26.png',
        'materials/images/27.png',
        'materials/images/28.png',
        
    ]

    labels_train = [
        'Alpha', 
        'Alpha', 
        'Alpha',
        'Alpha',
        'Alpha',
        'Alpha',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Sigma',
        'Sigma',
        'Sigma',
        'Sigma',
        'Sigma',
        'Sigma',
        'Delta',
        'Delta',
        'Delta',
        'Delta',
        'Delta',
        'Delta',
        ]

    # classification phase function
    classification.run(
        stimuli_train,
        labels = labels_train,

        phase_id = 'training_phase_2',
        supervised = True, # <-- this means there will be feedback
        randomize_presentation = True,
        num_blocks = 1,

        window = win,
        experiment_id = settings['experiment_id'],
        subject_info = subject,
        save_data = True,
        debug_mode = False,
        
        feedback_txt_position = [0, 250],
        click_instructions_position = [0, 200],
        continue_txt_position = [0, 200]
    )

    # - - - Exit Page - - -
    instructions.run(
        text_file = './materials/instructions/exit.txt',

        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
    )
#  # # # # # # # # # # #################################################################################
#Condition 2    
else:
    instructions.run(
        text_file = 'materials/instructions/C2_Train2.txt',	
        
        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
    )


    stimuli_train = [
        'materials/images/0.png',
        'materials/images/1.png',
        'materials/images/2.png',
        'materials/images/3.png',
        'materials/images/4.png',
        'materials/images/5.png',
        'materials/images/6.png',
        'materials/images/7.png',
        'materials/images/8.png',
        'materials/images/9.png',
        'materials/images/10.png',
        'materials/images/11.png',
    ]

    labels_train = [
        'Alpha', 
        'Alpha', 
        'Alpha',
        'Alpha',
        'Alpha',
        'Alpha',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        ]

    # classification phase function
    classification.run(
        stimuli_train,
        labels = labels_train,

        phase_id = 'training_phase_1',
        supervised = True, # <-- this means there will be feedback
        randomize_presentation = True,
        num_blocks = 1,

        window = win,
        experiment_id = settings['experiment_id'],
        subject_info = subject,
        save_data = True,
        debug_mode = False,
        
        feedback_txt_position = [0, 250],
        click_instructions_position = [0, 200],
        continue_txt_position = [0, 200],
        
        response_btn_labels = ['Alpha','Beta',],
        
        
    )




    # - - - Phase 2 - Test (no feedback) - - -

    # instructions function
    instructions.run(
        text_file = './materials/instructions/C2_Test.txt',

        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
        
        
        
    )


    stimuli_test = [
        'materials/images/0.png',
        'materials/images/1.png',
        'materials/images/2.png',
        'materials/images/3.png',
        'materials/images/4.png',
        'materials/images/5.png',
        'materials/images/6.png',
        'materials/images/7.png',
        'materials/images/8.png',
        'materials/images/9.png',
        'materials/images/10.png',
        'materials/images/11.png',
        'materials/images/12.png',
        'materials/images/13.png',
        'materials/images/14.png',
        'materials/images/15.png',
    ]

    labels_test = [
        'Alpha', 
        'Alpha', 
        'Alpha',
        'Alpha',
        'Alpha',
        'Alpha',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'test',
        'test',
        'test',
        'test',
        'test',
    ]

    # classification phase function
    classification.run(
        stimuli_test,
        labels = labels_test,
        response_btn_labels = ['Alpha','Beta','test'],

        phase_id = 'test_phase',
        supervised = False, # <-- no feedback
        randomize_presentation = True,
        num_blocks = 1,

        window = win,
        experiment_id = settings['experiment_id'],
        subject_info = subject,
        save_data = True,
        debug_mode = settings['debug_mode'],
        

        click_instructions_position = [0, 200],
        continue_txt_position = [0, 200]
    )

        #   Phase 3<--training_phase_2
        # instructions function
    instructions.run(
        text_file = 'materials/instructions/C2_Train2.txt',	
        
        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
    )


    stimuli_train = [
        'materials/images/0.png',
        'materials/images/1.png',
        'materials/images/2.png',
        'materials/images/3.png',
        'materials/images/4.png',
        'materials/images/5.png',
        'materials/images/6.png',
        'materials/images/7.png',
        'materials/images/8.png',
        'materials/images/9.png',
        'materials/images/10.png',
        'materials/images/11.png',
        'materials/images/17.png',
        'materials/images/18.png',
        'materials/images/19.png',
        'materials/images/20.png',
        'materials/images/21.png',
        'materials/images/22.png',
        'materials/images/23.png',
        'materials/images/24.png',
        'materials/images/25.png',
        'materials/images/26.png',
        'materials/images/27.png',
        'materials/images/28.png',
        
    ]

    labels_train = [
        'Alpha', 
        'Alpha', 
        'Alpha',
        'Alpha',
        'Alpha',
        'Alpha',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Beta',
        'Sigma',
        'Sigma',
        'Sigma',
        'Sigma',
        'Sigma',
        'Sigma',
        'Delta',
        'Delta',
        'Delta',
        'Delta',
        'Delta',
        'Delta',
        ]

    # classification phase function
    classification.run(
        stimuli_train,
        labels = labels_train,

        phase_id = 'training_phase_2',
        supervised = True, # <-- this means there will be feedback
        randomize_presentation = True,
        num_blocks = 1,

        window = win,
        experiment_id = settings['experiment_id'],
        subject_info = subject,
        save_data = True,
        debug_mode = False,
        
        feedback_txt_position = [0, 250],
        click_instructions_position = [0, 200],
        continue_txt_position = [0, 200]
    )

    # - - - Exit Page - - -
    instructions.run(
        text_file = './materials/instructions/exit.txt',

        window = win,
        debug_mode = settings['debug_mode'],
        window_color = settings['window_color'],
        continue_option = 'click',
    )
